package com.example.online_shopee

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

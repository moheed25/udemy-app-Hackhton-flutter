package com.example.otp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

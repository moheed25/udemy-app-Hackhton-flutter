import 'package:get/get.dart';

import '../Home Screen/Models/models.dart';

class OrderController extends GetxController {
  var orderlist = <Products>[].obs;
}

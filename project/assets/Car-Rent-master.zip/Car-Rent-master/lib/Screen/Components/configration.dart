
//Application name icon and slogan
String name = "Car Rent";
String iconimg = "assets/images/cicon2.png";
String dpimg = "assets/images/dp.jpg";
String slogan = "Have a good a trip.";
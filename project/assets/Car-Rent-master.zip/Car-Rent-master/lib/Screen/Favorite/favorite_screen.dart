import 'package:flutter/material.dart';

class FavariteScreen extends StatefulWidget {
  const FavariteScreen({ Key? key }) : super(key: key);

  @override
  State<FavariteScreen> createState() => _FavariteScreenState();
}

class _FavariteScreenState extends State<FavariteScreen> {
  @override
  Widget build(BuildContext context) {
    return Container(
      
    );
  }
}
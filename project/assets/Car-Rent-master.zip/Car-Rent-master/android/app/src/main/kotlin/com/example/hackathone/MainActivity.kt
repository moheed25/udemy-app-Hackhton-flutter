package com.example.hackathone

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
